package com.example.counter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView iteam1,iteam2,iteam3,iteam4,iteam5,iteam6,iteam7;
    int num1,num2,num3,num4,num5,num6,num7;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iteam1 = findViewById(R.id.numiteam1);
        iteam2 = findViewById(R.id.numiteam2);
        iteam3 = findViewById(R.id.numiteam3);
        iteam4 = findViewById(R.id.numiteam4);
        iteam5 = findViewById(R.id.numiteam5);
        iteam6 = findViewById(R.id.numiteam6);
        iteam7 = findViewById(R.id.numiteam7);
        num1=0;
        num2=0;
        num3=0;
        num4=0;
        num5=0;
        num6=0;
        num7=0;

    }
    public void add(View view){

        num1=num1+1;
        String val = String.valueOf(num1);
        iteam1.setText(val);
    }
    public void sub(View view){
        num1=num1-1;
        String val = String.valueOf(num1);
        iteam1.setText(val);
    }

    public void add2(View view){

        num2=num2+1;
        String val = String.valueOf(num2);
        iteam2.setText(val);
    }
    public void sub2(View view){
        num2=num2-1;
        String val = String.valueOf(num2);
        iteam2.setText(val);
    }

    public void add3(View view){

        num3=num3+1;
        String val = String.valueOf(num3);
        iteam3.setText(val);
    }
    public void sub3(View view){
        num3=num3-1;
        String val = String.valueOf(num3);
        iteam3.setText(val);
    }

    public void add4(View view){

        num4=num4+1;
        String val = String.valueOf(num4);
        iteam4.setText(val);
    }
    public void sub4(View view){
        num4=num4-1;
        String val = String.valueOf(num4);
        iteam4.setText(val);
    }
    public void add5(View view){

        num5=num5+1;
        String val = String.valueOf(num5);
        iteam5.setText(val);
    }
    public void sub5(View view){
        num5=num5-1;
        String val = String.valueOf(num5);
        iteam5.setText(val);
    }

    public void add6(View view){

        num6=num6+1;
        String val = String.valueOf(num6);
        iteam6.setText(val);
    }
    public void sub6(View view){
        num6=num6-1;
        String val = String.valueOf(num6);
        iteam6.setText(val);
    }

    public void add7(View view){

        num7=num7+1;
        String val = String.valueOf(num7);
        iteam7.setText(val);
    }
    public void sub7(View view){
        num7=num7-1;
        String val = String.valueOf(num7);
        iteam7.setText(val);
    }
    public void reset(View view){
        num1=0;
        num2=0;
        num3=0;
        num4=0;
        num5=0;
        num6=0;
        num7=0;
        String val = String.valueOf(num7);
        iteam1.setText(val);
        iteam2.setText(val);
        iteam3.setText(val);
        iteam4.setText(val);
        iteam5.setText(val);
        iteam6.setText(val);
        iteam7.setText(val);
    }



}